#!/bin/bash

dirs=`ls -d *-*`
lambda="0.00 0.05 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 0.95 1.00"
for dir in $dirs;do
cd $dir
cd complex/cM2A
	for l in $lambda;do
	echo $l
	cp /Users/liyishei/Desktop/bace-input/prod.in $l/
	done
cd ../cM2B
	for l in $lambda;do
	cp /Users/liyishei/Desktop/bace-input/prod.in $l/
	done
cd ../../ligands/lM2A
	for l in $lambda;do
	cp /Users/liyishei/Desktop/bace-input/prod.in $l/
	done
cd ../lM2B
	for l in $lambda;do
	cp /Users/liyishei/Desktop/bace-input/prod.in $l/
	done
cd ../../../
done
